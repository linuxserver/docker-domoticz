#include <windows.h>

#define _ANSI_SOURCE 1
#define NO_ANSI_KEYWORDS 1

#define _CLOCK_T_DEFINED_
#define _CLOCKID_T_DEFINED_
#define _SIZE_T_DEFINED_
#define _SSIZE_T_DEFINED_
#define _TIME_T_DEFINED_
#define _TIMER_T_DEFINED_
#define _OFF_T_DEFINED_
